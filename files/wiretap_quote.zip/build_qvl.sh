#!/bin/sh
git clone https://github.com/intel/SGX-TDX-DCAP-QuoteVerificationLibrary.git -b v1.1.8886
cd SGX-TDX-DCAP-QuoteVerificationLibrary/Src
./release -DBUILD_TESTS=OFF
cd ../..
echo "-- Done building QVL --"
