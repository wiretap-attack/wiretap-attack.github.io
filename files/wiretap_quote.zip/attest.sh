#!/bin/sh

QVL=$(realpath SGX-TDX-DCAP-QuoteVerificationLibrary/Src/Build/Release/dist/)
WD=$(realpath $PWD)
LD_LIBRARY_PATH=$QVL/lib $QVL/bin/AttestationApp --quote=$WD/quote.bin --trustedRootCaCert=$WD/collateral/root.pem --pckSignChain=$WD/collateral/pck_crl_chain.pem --tcbSignChain=$WD/collateral/tcb_info_chain.pem --tcbInfo=$WD/collateral/tcb_info.json --rootCaCrl=$WD/collateral/root_crl.der --pckCert=$WD/collateral/pck.pem --intermediateCaCrl=$WD/collateral/pck_crl.der --qeIdentity=$WD/collateral/qe_info.json
